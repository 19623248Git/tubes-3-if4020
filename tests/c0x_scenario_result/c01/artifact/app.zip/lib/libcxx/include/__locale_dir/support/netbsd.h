//===-----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

/* zig patch: https://github.com/llvm/llvm-project/pull/143055 */

#ifndef _LIBCPP___LOCALE_DIR_SUPPORT_NETBSD_H
#define _LIBCPP___LOCALE_DIR_SUPPORT_NETBSD_H

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

#include <__locale_dir/support/bsd_like.h>

#endif // _LIBCPP___LOCALE_DIR_SUPPORT_NETBSD_H
